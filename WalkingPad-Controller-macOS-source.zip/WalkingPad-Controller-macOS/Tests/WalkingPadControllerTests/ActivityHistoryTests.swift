import XCTest
@testable import WalkingPadController

final class ActivityHistoryTests: XCTestCase {
    func testStopsPersistenceResetsAndDeviceChanges() throws {
        var history = ActivityHistory()
        history.observe(device: "A", meters: 100, seconds: 60, speed: 3)
        XCTAssertTrue(history.activities.isEmpty)
        history.observe(device: "A", meters: 120, seconds: 70, speed: 0)
        XCTAssertEqual(history.activities.count, 1)
        history.observe(device: "A", meters: 121, seconds: 71, speed: nil)
        XCTAssertEqual(history.activities.first?.meters, 121)
        history = try JSONDecoder().decode(ActivityHistory.self, from: JSONEncoder().encode(history))
        history.observe(device: "A", meters: 121, seconds: 71, speed: 0)
        XCTAssertEqual(history.activities.count, 1)
        history.observe(device: "A", meters: 0, seconds: 0, speed: 2)
        history.observe(device: "A", meters: 30, seconds: 15, speed: 0)
        XCTAssertEqual(history.activities.count, 2)
        history.reset()
        history.observe(device: "A", meters: 30, seconds: 15, speed: 0)
        XCTAssertTrue(history.activities.isEmpty)
        history.observe(device: "A", meters: 0, seconds: 0, speed: 2)
        history.observe(device: "B", meters: 10, seconds: 5, speed: 2)
        history.observe(device: "B", meters: 20, seconds: 10, speed: 0)
        XCTAssertEqual(history.activities.count, 2)
    }
}
