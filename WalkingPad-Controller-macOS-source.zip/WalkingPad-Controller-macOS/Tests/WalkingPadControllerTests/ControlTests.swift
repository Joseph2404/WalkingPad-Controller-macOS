import XCTest
@testable import WalkingPadController

final class ControlTests: XCTestCase {
    func testStartConfirmsMovementAndStopSupersedesWaiting() {
        var s = grantedSession()
        s.confirmMotorCommandsFromTelemetry = true
        XCTAssertEqual(s.begin(.start, now: 1), Data([7]))
        XCTAssertNil(s.didWrite(error: nil))
        XCTAssertNil(s.observeSpeed(kph: 0))
        XCTAssertEqual(s.observeSpeed(kph: 1.6), .accepted(.start))
        _ = s.begin(.speed(320), now: 2)
        _ = s.didWrite(error: nil)
        s.makeRoomForStop()
        XCTAssertEqual(s.begin(.stop, now: 3), Data([8, 1]))
        _ = s.didWrite(error: nil)
        XCTAssertEqual(s.observeSpeed(kph: 0), .accepted(.stop))
        XCTAssertNil(s.pending)
    }

    private func grantedSession() -> FTMSControlSession {
        var s = FTMSControlSession()
        _ = s.begin(.requestControl, now: 0)
        _ = s.didWrite(error: nil)
        _ = s.receive(Data([0x80, 0, 1]))
        return s
    }

    func testWP400U4SpeedGridAndDeskCap() throws {
        let limits = try XCTUnwrap(SpeedLimits(data: Data([0xA0, 0, 0x1A, 4, 10, 0])))
        XCTAssertEqual(limits.target(mph: 1), 160)
        XCTAssertEqual(limits.target(mph: 2.1), 340)
        XCTAssertEqual(limits.target(mph: 3), 480)
        XCTAssertEqual(limits.target(mph: 4), 640)
        XCTAssertNil(limits.target(mph: 4.1))
        XCTAssertNil(limits.target(mph: .nan))
        XCTAssertNil(limits.target(mph: .infinity))
        XCTAssertNil(limits.target(mph: 0))
        XCTAssertNil(limits.target(mph: -1))
        for step in 10...40 {
            let target = try XCTUnwrap(limits.target(mph: Double(step) / 10))
            XCTAssertGreaterThanOrEqual(target, limits.minimum)
            XCTAssertLessThanOrEqual(target, limits.cappedMaximum)
            XCTAssertEqual((target - limits.minimum) % limits.increment, 0)
        }
    }

    func testDeviceMaximumWinsOverAppCap() throws {
        let limits = try XCTUnwrap(SpeedLimits(data: Data([160, 0, 0x2C, 1, 10, 0])))
        XCTAssertEqual(limits.target(mph: 3), 300)
        XCTAssertNil(SpeedLimits(data: Data([160, 0, 160, 0, 10, 0])))
        XCTAssertNil(SpeedLimits(data: Data([160, 0, 0x1A, 4, 0, 0])))
    }

    func testMotorCommandsRequireControl() {
        var s = FTMSControlSession()
        XCTAssertNil(s.begin(.speed(340), now: 0))
        XCTAssertNil(s.begin(.stop, now: 0))
        XCTAssertEqual(s.begin(.requestControl, now: 0), Data([0]))
        XCTAssertNil(s.begin(.requestControl, now: 0))
    }

    func testWriteAcknowledgementAloneDoesNotGrantControl() {
        var s = FTMSControlSession()
        _ = s.begin(.requestControl, now: 0)
        XCTAssertNil(s.didWrite(error: nil))
        XCTAssertFalse(s.granted)
        XCTAssertEqual(s.receive(Data([0x80, 0, 1])), .accepted(.requestControl))
        XCTAssertTrue(s.granted)
    }

    func testIndicationBeforeWriteAcknowledgement() {
        var s = FTMSControlSession()
        _ = s.begin(.requestControl, now: 0)
        XCTAssertNil(s.receive(Data([0x80, 0, 1])))
        XCTAssertNil(s.receive(Data([0x80, 0, 5]))) // Duplicate cannot replace the first matched reply.
        XCTAssertFalse(s.granted)
        XCTAssertEqual(s.didWrite(error: nil), .accepted(.requestControl))
    }

    func testMismatchedAndMalformedRepliesCannotCompleteCommand() {
        var s = grantedSession()
        XCTAssertEqual(s.begin(.speed(340), now: 1), Data([2, 0x54, 1]))
        _ = s.didWrite(error: nil)
        XCTAssertNil(s.receive(Data([0x80, 8, 1])))
        XCTAssertNil(s.receive(Data([0x80, 2])))
        XCTAssertNil(s.receive(Data([0x80, 2, 9])))
        XCTAssertNil(s.begin(.speed(350), now: 2))
        XCTAssertEqual(s.receive(Data([0x80, 2, 1])), .accepted(.speed(340)))
    }

    func testTimedOutSpeedCannotBeReplayedOrResumed() {
        var s = grantedSession()
        _ = s.begin(.speed(340), now: 1)
        _ = s.didWrite(error: nil)
        XCTAssertNil(s.tick(now: 3.9))
        XCTAssertNotNil(s.tick(now: 4))
        XCTAssertTrue(s.requiresReconnect)
        XCTAssertFalse(s.granted)
        XCTAssertNil(s.receive(Data([0x80, 2, 1])))
        XCTAssertNil(s.begin(.requestControl, now: 5))
        XCTAssertNil(s.begin(.speed(340), now: 5))
        s = FTMSControlSession() // A new connection starts without permission or queued commands.
        XCTAssertFalse(s.granted)
        XCTAssertNil(s.pending)
    }

    func testRejectedSpeedStillAllowsStop() {
        var s = grantedSession()
        _ = s.begin(.speed(340), now: 1)
        _ = s.didWrite(error: nil)
        XCTAssertNotNil(s.receive(Data([0x80, 2, 2])))
        XCTAssertTrue(s.speedRejected)
        XCTAssertNil(s.begin(.speed(330), now: 2))
        XCTAssertEqual(s.begin(.stop, now: 2), Data([8, 1]))
        _ = s.didWrite(error: nil)
        XCTAssertEqual(s.receive(Data([0x80, 8, 1])), .accepted(.stop))
    }

    func testControlDeniedNeverEnablesSpeed() {
        var s = FTMSControlSession()
        _ = s.begin(.requestControl, now: 0)
        _ = s.didWrite(error: nil)
        XCTAssertNotNil(s.receive(Data([0x80, 0, 5])))
        XCTAssertFalse(s.granted)
        XCTAssertNil(s.begin(.speed(340), now: 1))
    }

    func testWriteErrorInvalidatesSessionEvenAfterSuccessIndication() {
        var s = grantedSession()
        _ = s.begin(.speed(340), now: 0)
        _ = s.receive(Data([0x80, 2, 1]))
        XCTAssertNotNil(s.didWrite(error: "Disconnected"))
        XCTAssertTrue(s.requiresReconnect)
        XCTAssertFalse(s.granted)
    }

    func testRevocationDiscardsInFlightCommand() {
        var s = grantedSession()
        _ = s.begin(.speed(340), now: 0)
        s.invalidate()
        XCTAssertNil(s.didWrite(error: nil))
        XCTAssertNil(s.receive(Data([0x80, 2, 1])))
        XCTAssertNil(s.pending)
        XCTAssertFalse(s.granted)
    }

    func testAppliedSpeedWithoutIndicationKeepsControl() {
        var s = grantedSession()
        s.confirmMotorCommandsFromTelemetry = true
        _ = s.begin(.speed(340), now: 1)
        _ = s.didWrite(error: nil)
        XCTAssertNil(s.observeSpeed(kph: 2.5))
        XCTAssertEqual(s.observeSpeed(kph: 3.4), .accepted(.speed(340)))
        XCTAssertNil(s.tick(now: 20))
        XCTAssertTrue(s.granted)
        XCTAssertNotNil(s.begin(.speed(640), now: 21))
        _ = s.didWrite(error: nil)
        XCTAssertNil(s.receive(Data([0x80, 2, 1]))) // Late previous success is ignored.
        XCTAssertNotNil(s.pending)
        XCTAssertEqual(s.observeSpeed(kph: 6.4), .accepted(.speed(640)))
    }

    func testMissingMotorConfirmationDoesNotForceReconnectAndStopWorks() {
        var s = grantedSession()
        s.confirmMotorCommandsFromTelemetry = true
        _ = s.begin(.speed(340), now: 1)
        _ = s.didWrite(error: nil)
        XCTAssertEqual(s.tick(now: 11), .speedSent)
        XCTAssertTrue(s.granted)
        XCTAssertFalse(s.requiresReconnect)
        XCTAssertEqual(s.begin(.stop, now: 12), Data([8, 1]))
        _ = s.didWrite(error: nil)
        XCTAssertEqual(s.observeSpeed(kph: 0), .accepted(.stop))
    }
}
