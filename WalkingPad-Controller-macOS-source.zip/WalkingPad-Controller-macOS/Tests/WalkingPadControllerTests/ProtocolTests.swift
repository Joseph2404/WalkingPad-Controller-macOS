import XCTest
@testable import WalkingPadController

final class ProtocolTests: XCTestCase {
    func testElapsedSessionClock() {
        let reported = Data([0x84, 0x25, 0x54, 0x01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x1D, 0, 0, 0, 0])
        XCTAssertEqual(TreadmillParser.ftmsElapsedSeconds(reported), 29)
        XCTAssertEqual(TreadmillParser.ftmsElapsedSeconds(Data([1, 4, 0x34, 0x12])), 0x1234)
        XCTAssertEqual(TreadmillParser.ftmsElapsedSeconds(Data([0, 4, 0, 0, 0, 0])), 0)
        XCTAssertNil(TreadmillParser.ftmsElapsedSeconds(Data([0, 4, 0, 0, 1])))
        XCTAssertNil(TreadmillParser.ftmsElapsedSeconds(Data([0, 0, 0, 0])))
        XCTAssertNil(TreadmillParser.ftmsElapsedSeconds(Data()))
        // All optional fields before elapsed time, with instantaneous speed.
        var full = Data([0xFE, 0x07])
        full.append(contentsOf: Array(repeating: UInt8(0), count: 24))
        full.append(contentsOf: [0x34, 0x12])
        XCTAssertEqual(TreadmillParser.ftmsElapsedSeconds(full), 0x1234)
    }

    func testDistanceExtractionWithOptionalSpeedFields() {
        XCTAssertEqual(TreadmillParser.ftmsDistanceMeters(Data([0x84, 0x25, 0x54, 1, 0x49, 6, 0])), 1609)
        XCTAssertEqual(TreadmillParser.ftmsDistanceMeters(Data([6, 0, 0x54, 1, 0x22, 1, 0x49, 6, 0])), 1609)
        XCTAssertEqual(TreadmillParser.ftmsDistanceMeters(Data([5, 0, 0x49, 6, 0])), 1609)
        XCTAssertEqual(TreadmillParser.ftmsDistanceMeters(Data([4, 0, 0, 0, 0, 0, 1])), 65536)
        XCTAssertEqual(TreadmillParser.ftmsDistanceMeters(Data([4, 0, 0, 0, 0, 0, 0])), 0)
        XCTAssertNil(TreadmillParser.ftmsDistanceMeters(Data([0, 0, 0x54, 1])))
        XCTAssertNil(TreadmillParser.ftmsDistanceMeters(Data([4, 0, 0x54, 1, 0x49, 6])))
        XCTAssertNil(TreadmillParser.ftmsDistanceMeters(Data()))
        XCTAssertEqual(DistanceUnits.miles(fromMeters: 1609.344), 1, accuracy: 0.0000001)
    }

    func testReportedWP400U4SpeedDisplaysInMPH() throws {
        let packet = Data([0x84, 0x25, 0x54, 0x01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x1D, 0, 0, 0, 0])
        let kph = try XCTUnwrap(TreadmillParser.ftmsSpeed(packet))
        XCTAssertEqual(kph, 3.4)
        XCTAssertEqual(SpeedUnits.mph(fromKPH: kph), 2.1126620536, accuracy: 0.0000001)
        XCTAssertEqual(String(format: "%.1f", SpeedUnits.mph(fromKPH: kph)), "2.1")
        XCTAssertEqual(SpeedUnits.mph(fromKPH: 1.609344), 1, accuracy: 0.0000001)
        XCTAssertEqual(SpeedUnits.mph(fromKPH: 0), 0)
    }

    func testLegacyFrames() {
        XCTAssertEqual([UInt8](WiLinkCommand.start), [0xF7, 0xA2, 0x04, 0x01, 0xA7, 0xFD])
        XCTAssertEqual([UInt8](WiLinkCommand.speed(kph: 1.5)), [0xF7, 0xA2, 0x01, 0x0F, 0xB2, 0xFD])
        XCTAssertEqual([UInt8](WiLinkCommand.stop), [0xF7, 0xA2, 0x01, 0x00, 0xA3, 0xFD])
    }

    func testFTMSSpeedUsesLittleEndianHundredths() {
        XCTAssertEqual([UInt8](FTMSCommand.speed(kph: 4.0)), [0x02, 0x90, 0x01])
    }

    func testSpeedRange() {
        let parsed = TreadmillParser.supportedSpeedRange(Data([100, 0, 0x58, 0x02, 10, 0]))
        XCTAssertEqual(parsed?.0, 1.0)
        XCTAssertEqual(parsed?.1, 6.0)
        XCTAssertEqual(parsed?.2, 0.1)
    }

    func testFTMSSpeedAndAbsentSpeedField() {
        XCTAssertEqual(TreadmillParser.ftmsSpeed(Data([0, 0, 0x90, 0x01])), 4.0)
        XCTAssertEqual(TreadmillParser.ftmsSpeed(Data([0, 0, 0, 0])), 0.0)
        // More Data bit set: bytes 2–3 are not instantaneous speed.
        XCTAssertNil(TreadmillParser.ftmsSpeed(Data([1, 0, 0x90, 0x01])))
        XCTAssertNil(TreadmillParser.ftmsSpeed(Data([0, 0, 0x90])))
        XCTAssertNil(TreadmillParser.ftmsSpeed(Data()))
    }

    func testRejectsMalformedSpeedRanges() {
        XCTAssertNil(TreadmillParser.supportedSpeedRange(Data([100, 0, 50, 0, 10, 0])))
        XCTAssertNil(TreadmillParser.supportedSpeedRange(Data([100, 0, 100, 0, 10, 0])))
        XCTAssertNil(TreadmillParser.supportedSpeedRange(Data([100, 0, 0x58, 2, 0, 0])))
        XCTAssertNil(TreadmillParser.supportedSpeedRange(Data([100, 0])))
    }

    func testSpeedIsUnknownUntilReceivedAndExpires() {
        var sample = SpeedSample()
        XCTAssertNil(sample.current(at: 10))
        sample.receive(0, at: 10)
        XCTAssertEqual(sample.current(at: 10), 0)
        XCTAssertEqual(sample.current(at: 12.9), 0)
        XCTAssertNil(sample.current(at: 13))
        sample.receive(1.5, at: 14)
        XCTAssertEqual(sample.current(at: 14), 1.5)
        sample = SpeedSample() // Same invalidation used on disconnect.
        XCTAssertNil(sample.current(at: 14))
    }
}
