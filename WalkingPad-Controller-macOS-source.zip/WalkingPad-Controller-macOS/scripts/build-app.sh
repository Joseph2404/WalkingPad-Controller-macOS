#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_ROOT="$PROJECT_ROOT/build"
APP_PATH="$BUILD_ROOT/WalkingPad Controller.app"
mkdir -p "$APP_PATH/Contents/MacOS" "$APP_PATH/Contents/Resources" "$BUILD_ROOT/module-cache"
cp "$PROJECT_ROOT/Support/Info.plist" "$APP_PATH/Contents/Info.plist"
cp "$PROJECT_ROOT/Support/AppIcon.icns" "$APP_PATH/Contents/Resources/AppIcon.icns"
for ARCH in arm64 x86_64; do
    xcrun swiftc -O -target "$ARCH-apple-macosx13.0" \
        -module-cache-path "$BUILD_ROOT/module-cache" \
        "$PROJECT_ROOT"/Sources/WalkingPadController/*.swift \
        -o "$BUILD_ROOT/WalkingPadController-$ARCH"
done
xcrun lipo -create "$BUILD_ROOT/WalkingPadController-arm64" \
    "$BUILD_ROOT/WalkingPadController-x86_64" \
    -output "$APP_PATH/Contents/MacOS/WalkingPadController"
codesign --force --sign - "$APP_PATH"
codesign --verify --strict "$APP_PATH"
printf 'Built %s\n' "$APP_PATH"
