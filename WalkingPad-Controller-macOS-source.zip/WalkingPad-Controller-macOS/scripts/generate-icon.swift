import AppKit

// Vector artwork, rendered at every macOS icon size.
let destination = CommandLine.arguments[1]
try FileManager.default.createDirectory(atPath: destination, withIntermediateDirectories: true)
func render(_ pixels: Int, name: String) throws {
    let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: pixels, pixelsHigh: pixels,
        bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false,
        colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
    let transform = NSAffineTransform()
    transform.scale(by: CGFloat(pixels) / 1024)
    transform.concat()
    let tile = NSBezierPath(roundedRect: NSRect(x: 64, y: 64, width: 896, height: 896),
                            xRadius: 200, yRadius: 200)
    NSGradient(starting: NSColor(calibratedRed: 0.10, green: 0.13, blue: 0.17, alpha: 1),
               ending: NSColor(calibratedRed: 0.23, green: 0.28, blue: 0.33, alpha: 1))!
        .draw(in: tile, angle: 80)
    NSColor.white.withAlphaComponent(0.13).setStroke()
    tile.lineWidth = 3
    tile.stroke()
    let amber = NSColor(calibratedRed: 1, green: 0.68, blue: 0.29, alpha: 1)
    let base = NSBezierPath(roundedRect: NSRect(x: 205, y: 274, width: 620, height: 112),
                            xRadius: 56, yRadius: 56)
    amber.setFill()
    base.fill()
    let belt = NSBezierPath(roundedRect: NSRect(x: 245, y: 311, width: 540, height: 38),
                            xRadius: 19, yRadius: 19)
    NSColor(calibratedRed: 0.12, green: 0.16, blue: 0.20, alpha: 1).setFill()
    belt.fill()
    let frame = NSBezierPath()
    frame.move(to: NSPoint(x: 738, y: 386))
    frame.line(to: NSPoint(x: 650, y: 704))
    frame.line(to: NSPoint(x: 492, y: 704))
    frame.move(to: NSPoint(x: 683, y: 584))
    frame.line(to: NSPoint(x: 485, y: 584))
    frame.lineWidth = 45
    frame.lineCapStyle = .round
    frame.lineJoinStyle = .round
    NSColor(calibratedWhite: 0.96, alpha: 1).setStroke()
    frame.stroke()
    let console = NSBezierPath(roundedRect: NSRect(x: 461, y: 680, width: 116, height: 58),
                               xRadius: 18, yRadius: 18)
    amber.setFill()
    console.fill()
    NSGraphicsContext.restoreGraphicsState()
    try bitmap.representation(using: .png, properties: [:])!
        .write(to: URL(fileURLWithPath: destination).appendingPathComponent(name))
}
for size in [16, 32, 128, 256, 512] {
    try render(size, name: "icon_\(size)x\(size).png")
    try render(size * 2, name: "icon_\(size)x\(size)@2x.png")
}

func lengthBytes(_ count: Int) -> Data {
    var value = UInt32(count).bigEndian
    return withUnsafeBytes(of: &value) { Data($0) }
}
var chunks = Data()
for (tag, name) in [
    ("icp4", "icon_16x16.png"), ("icp5", "icon_32x32.png"),
    ("icp6", "icon_32x32@2x.png"), ("ic07", "icon_128x128.png"),
    ("ic08", "icon_256x256.png"), ("ic09", "icon_512x512.png"),
    ("ic10", "icon_512x512@2x.png"), ("ic11", "icon_16x16@2x.png"),
    ("ic12", "icon_32x32@2x.png"), ("ic13", "icon_128x128@2x.png"),
    ("ic14", "icon_256x256@2x.png")
] {
    let png = try Data(contentsOf: URL(fileURLWithPath: destination).appendingPathComponent(name))
    chunks.append(Data(tag.utf8))
    chunks.append(lengthBytes(png.count + 8))
    chunks.append(png)
}
var icon = Data("icns".utf8)
icon.append(lengthBytes(chunks.count + 8))
icon.append(chunks)
try icon.write(to: URL(fileURLWithPath: destination).deletingPathExtension().appendingPathExtension("icns"))
